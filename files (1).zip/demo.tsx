import React from "react";
import Component from "@/components/ui/saa-s-template";
import DashboardEkspedisi from "@/components/ui/dashboard-ekspedisi";

export default function Demo() {
  return (
    <main>
      <Component />
      <DashboardEkspedisi />
    </main>
  );
}
