"""
Backend Python (FastAPI) opsional untuk Dashboard Ekspedisi.

Frontend tetap berjalan dengan data mock lokal. Backend ini menyediakan
data yang sama lewat API supaya mudah diganti ke sumber data nyata.

Jalankan:
    pip install fastapi uvicorn
    uvicorn backend.main:app --reload --port 8000
"""
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

Status = Literal["Terkirim", "Dalam Proses", "Gagal Kirim"]


class Kpi(BaseModel):
    id: Literal["terkirim", "transit", "gagal"]
    label: str
    value: int
    delta: float
    positiveIsGood: bool


class CityVolume(BaseModel):
    kota: str
    volume: int


class DailyOnTime(BaseModel):
    tanggal: str
    ontime: int


class TrackingEvent(BaseModel):
    waktu: str
    lokasi: str
    keterangan: str


class Resi(BaseModel):
    nomor: str
    status: Status
    asal: str
    tujuan: str
    kurir: str
    updateTerakhir: str
    riwayat: list[TrackingEvent]


KPI = [
    Kpi(id="terkirim", label="Paket Terkirim", value=12480, delta=8.4, positiveIsGood=True),
    Kpi(id="transit", label="Paket Dalam Proses / Transit", value=3265, delta=3.1, positiveIsGood=True),
    Kpi(id="gagal", label="Paket Gagal Kirim", value=412, delta=-12.6, positiveIsGood=False),
]

CITY_VOLUME = [
    CityVolume(kota=k, volume=v)
    for k, v in [
        ("Jakarta", 4820), ("Surabaya", 3150), ("Bandung", 2410), ("Medan", 1760),
        ("Semarang", 1535), ("Makassar", 1290), ("Denpasar", 1105), ("Yogyakarta", 980),
    ]
]

ON_TIME = [
    DailyOnTime(tanggal=f"{d:02d} Okt", ontime=v)
    for d, v in zip(range(3, 17), [91, 93, 89, 92, 94, 90, 87, 85, 88, 93, 95, 94, 96, 95])
]

RESI_DB: dict[str, Resi] = {
    "JNE001234567": Resi(
        nomor="JNE001234567", status="Terkirim", asal="Jakarta", tujuan="Bandung",
        kurir="JNE", updateTerakhir="15 Okt 2026, 14:20 WIB",
        riwayat=[
            TrackingEvent(waktu="15 Okt 2026, 14:20", lokasi="Bandung", keterangan="Paket diterima oleh penerima"),
            TrackingEvent(waktu="14 Okt 2026, 09:30", lokasi="Jakarta", keterangan="Paket diterima dari pengirim"),
        ],
    ),
    "SPX998877665": Resi(
        nomor="SPX998877665", status="Dalam Proses", asal="Surabaya", tujuan="Medan",
        kurir="SPX Express", updateTerakhir="16 Okt 2026, 07:05 WIB",
        riwayat=[
            TrackingEvent(waktu="16 Okt 2026, 07:05", lokasi="Hub Jakarta", keterangan="Paket transit di hub sortir"),
            TrackingEvent(waktu="15 Okt 2026, 13:15", lokasi="Surabaya", keterangan="Paket diterima dari pengirim"),
        ],
    ),
    "JNT445566778": Resi(
        nomor="JNT445566778", status="Gagal Kirim", asal="Semarang", tujuan="Denpasar",
        kurir="J&T Express", updateTerakhir="16 Okt 2026, 11:30 WITA",
        riwayat=[
            TrackingEvent(waktu="16 Okt 2026, 11:30", lokasi="Denpasar", keterangan="Gagal kirim: penerima tidak berada di tempat"),
            TrackingEvent(waktu="14 Okt 2026, 10:00", lokasi="Semarang", keterangan="Paket diterima dari pengirim"),
        ],
    ),
    "ANT112233445": Resi(
        nomor="ANT112233445", status="Dalam Proses", asal="Yogyakarta", tujuan="Makassar",
        kurir="Anteraja", updateTerakhir="16 Okt 2026, 05:40 WIB",
        riwayat=[
            TrackingEvent(waktu="16 Okt 2026, 05:40", lokasi="Bandara Adisutjipto", keterangan="Paket menunggu penerbangan"),
            TrackingEvent(waktu="15 Okt 2026, 12:05", lokasi="Yogyakarta", keterangan="Paket diterima dari pengirim"),
        ],
    ),
}

app = FastAPI(title="KirimKu API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],
    allow_methods=["GET"],
    allow_headers=["*"],
)


@app.get("/api/kpi", response_model=list[Kpi])
def get_kpi():
    return KPI


@app.get("/api/volume-kota", response_model=list[CityVolume])
def get_city_volume():
    return CITY_VOLUME


@app.get("/api/ketepatan-waktu", response_model=list[DailyOnTime])
def get_on_time():
    return ON_TIME


@app.get("/api/resi/{nomor}", response_model=Resi)
def get_resi(nomor: str):
    data = RESI_DB.get(nomor.strip().upper())
    if data is None:
        raise HTTPException(status_code=404, detail="Nomor resi tidak ditemukan")
    return data
