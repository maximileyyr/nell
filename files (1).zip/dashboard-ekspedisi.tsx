"use client";

import * as React from "react";
import { Bar, BarChart, CartesianGrid, Line, LineChart, XAxis, YAxis } from "recharts";
import {
  AlertTriangle,
  CheckCircle2,
  MapPin,
  Package,
  PackageCheck,
  PackageX,
  Search,
  TrendingDown,
  TrendingUp,
  Truck,
  type LucideIcon,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart";
import { Input } from "@/components/ui/input";

/* ------------------------------------------------------------------ */
/* Tipe data                                                           */
/* ------------------------------------------------------------------ */
export type StatusPengiriman = "Terkirim" | "Dalam Proses" | "Gagal Kirim";

export interface KpiItem {
  id: "terkirim" | "transit" | "gagal";
  label: string;
  value: number;
  /** Perubahan (%) dibanding periode sebelumnya */
  delta: number;
  /** true bila kenaikan dianggap baik (mis. paket terkirim); false untuk gagal kirim */
  positiveIsGood: boolean;
}

export interface CityVolume {
  kota: string;
  volume: number;
}

export interface DailyOnTime {
  tanggal: string;
  ontime: number;
}

export interface TrackingEvent {
  waktu: string;
  lokasi: string;
  keterangan: string;
}

export interface ResiData {
  nomor: string;
  status: StatusPengiriman;
  asal: string;
  tujuan: string;
  kurir: string;
  updateTerakhir: string;
  riwayat: TrackingEvent[]; // terbaru di atas
}

/* ------------------------------------------------------------------ */
/* Data mock (ganti dengan API di kemudian hari)                       */
/* ------------------------------------------------------------------ */
export const kpiData: KpiItem[] = [
  { id: "terkirim", label: "Paket Terkirim", value: 12480, delta: 8.4, positiveIsGood: true },
  { id: "transit", label: "Paket Dalam Proses / Transit", value: 3265, delta: 3.1, positiveIsGood: true },
  { id: "gagal", label: "Paket Gagal Kirim", value: 412, delta: -12.6, positiveIsGood: false },
];

export const cityVolume: CityVolume[] = [
  { kota: "Jakarta", volume: 4820 },
  { kota: "Surabaya", volume: 3150 },
  { kota: "Bandung", volume: 2410 },
  { kota: "Medan", volume: 1760 },
  { kota: "Semarang", volume: 1535 },
  { kota: "Makassar", volume: 1290 },
  { kota: "Denpasar", volume: 1105 },
  { kota: "Yogyakarta", volume: 980 },
];

export const dailyOnTime: DailyOnTime[] = [
  { tanggal: "03 Okt", ontime: 91 },
  { tanggal: "04 Okt", ontime: 93 },
  { tanggal: "05 Okt", ontime: 89 },
  { tanggal: "06 Okt", ontime: 92 },
  { tanggal: "07 Okt", ontime: 94 },
  { tanggal: "08 Okt", ontime: 90 },
  { tanggal: "09 Okt", ontime: 87 },
  { tanggal: "10 Okt", ontime: 85 },
  { tanggal: "11 Okt", ontime: 88 },
  { tanggal: "12 Okt", ontime: 93 },
  { tanggal: "13 Okt", ontime: 95 },
  { tanggal: "14 Okt", ontime: 94 },
  { tanggal: "15 Okt", ontime: 96 },
  { tanggal: "16 Okt", ontime: 95 },
];

export const resiDatabase: Record<string, ResiData> = {
  JNE001234567: {
    nomor: "JNE001234567",
    status: "Terkirim",
    asal: "Jakarta",
    tujuan: "Bandung",
    kurir: "JNE",
    updateTerakhir: "15 Okt 2026, 14:20 WIB",
    riwayat: [
      { waktu: "15 Okt 2026, 14:20", lokasi: "Bandung", keterangan: "Paket diterima oleh penerima" },
      { waktu: "15 Okt 2026, 08:45", lokasi: "Bandung", keterangan: "Paket dibawa kurir untuk diantar" },
      { waktu: "14 Okt 2026, 21:10", lokasi: "Hub Bandung", keterangan: "Tiba di hub tujuan" },
      { waktu: "14 Okt 2026, 09:30", lokasi: "Jakarta", keterangan: "Paket diterima dari pengirim" },
    ],
  },
  SPX998877665: {
    nomor: "SPX998877665",
    status: "Dalam Proses",
    asal: "Surabaya",
    tujuan: "Medan",
    kurir: "SPX Express",
    updateTerakhir: "16 Okt 2026, 07:05 WIB",
    riwayat: [
      { waktu: "16 Okt 2026, 07:05", lokasi: "Hub Jakarta", keterangan: "Paket transit di hub sortir" },
      { waktu: "15 Okt 2026, 19:40", lokasi: "Surabaya", keterangan: "Paket berangkat dari gudang asal" },
      { waktu: "15 Okt 2026, 13:15", lokasi: "Surabaya", keterangan: "Paket diterima dari pengirim" },
    ],
  },
  JNT445566778: {
    nomor: "JNT445566778",
    status: "Gagal Kirim",
    asal: "Semarang",
    tujuan: "Denpasar",
    kurir: "J&T Express",
    updateTerakhir: "16 Okt 2026, 11:30 WITA",
    riwayat: [
      { waktu: "16 Okt 2026, 11:30", lokasi: "Denpasar", keterangan: "Gagal kirim: penerima tidak berada di tempat" },
      { waktu: "16 Okt 2026, 08:00", lokasi: "Denpasar", keterangan: "Paket dibawa kurir untuk diantar" },
      { waktu: "15 Okt 2026, 22:50", lokasi: "Hub Denpasar", keterangan: "Tiba di hub tujuan" },
      { waktu: "14 Okt 2026, 10:00", lokasi: "Semarang", keterangan: "Paket diterima dari pengirim" },
    ],
  },
  ANT112233445: {
    nomor: "ANT112233445",
    status: "Dalam Proses",
    asal: "Yogyakarta",
    tujuan: "Makassar",
    kurir: "Anteraja",
    updateTerakhir: "16 Okt 2026, 05:40 WIB",
    riwayat: [
      { waktu: "16 Okt 2026, 05:40", lokasi: "Bandara Adisutjipto", keterangan: "Paket menunggu penerbangan" },
      { waktu: "15 Okt 2026, 20:25", lokasi: "Hub Yogyakarta", keterangan: "Paket selesai disortir" },
      { waktu: "15 Okt 2026, 12:05", lokasi: "Yogyakarta", keterangan: "Paket diterima dari pengirim" },
    ],
  },
};

/* ------------------------------------------------------------------ */
/* Konfigurasi tampilan                                                */
/* ------------------------------------------------------------------ */
const kpiMeta: Record<KpiItem["id"], { icon: LucideIcon; accent: string }> = {
  terkirim: { icon: PackageCheck, accent: "text-emerald-400 bg-emerald-500/10 ring-emerald-500/20" },
  transit: { icon: Truck, accent: "text-sky-400 bg-sky-500/10 ring-sky-500/20" },
  gagal: { icon: PackageX, accent: "text-red-400 bg-red-500/10 ring-red-500/20" },
};

const statusStyle: Record<StatusPengiriman, string> = {
  Terkirim: "border-emerald-500/30 bg-emerald-500/10 text-emerald-300",
  "Dalam Proses": "border-amber-500/30 bg-amber-500/10 text-amber-300",
  "Gagal Kirim": "border-red-500/30 bg-red-500/10 text-red-300",
};

const statusIcon: Record<StatusPengiriman, LucideIcon> = {
  Terkirim: CheckCircle2,
  "Dalam Proses": Truck,
  "Gagal Kirim": AlertTriangle,
};

const volumeConfig = { volume: { label: "Paket", color: "#38bdf8" } } satisfies ChartConfig;
const onTimeConfig = { ontime: { label: "Tepat waktu (%)", color: "#34d399" } } satisfies ChartConfig;

const cardClass = "bg-gray-900/60 border-gray-800 backdrop-blur text-white";
const tooltipClass = "bg-gray-900 border-gray-700 text-white";
const tickStyle = { fill: "#9ca3af", fontSize: 12 };
const gridStroke = "rgba(255,255,255,0.08)";

const nf = new Intl.NumberFormat("id-ID");

/* ------------------------------------------------------------------ */
/* Komponen                                                            */
/* ------------------------------------------------------------------ */
export interface DashboardEkspedisiProps {
  kpi?: KpiItem[];
  cityVolume?: CityVolume[];
  dailyOnTime?: DailyOnTime[];
  resiDatabase?: Record<string, ResiData>;
}

type LookupState =
  | { kind: "idle" }
  | { kind: "empty" }
  | { kind: "notfound"; query: string }
  | { kind: "found"; data: ResiData };

export default function DashboardEkspedisi({
  kpi = kpiData,
  cityVolume: cityData = cityVolume,
  dailyOnTime: onTimeData = dailyOnTime,
  resiDatabase: resiDb = resiDatabase,
}: DashboardEkspedisiProps) {
  const [resiInput, setResiInput] = React.useState("");
  const [lookup, setLookup] = React.useState<LookupState>({ kind: "idle" });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const query = resiInput.trim().toUpperCase();
    if (!query) return setLookup({ kind: "empty" });
    const data = resiDb[query];
    setLookup(data ? { kind: "found", data } : { kind: "notfound", query });
  };

  return (
    <div className="bg-black text-white">
      <div className="max-w-7xl mx-auto px-6 pb-24 space-y-20">
        {/* Ringkasan */}
        <section id="ringkasan" className="scroll-mt-24">
          <h2 className="text-2xl md:text-3xl font-medium mb-2">Ringkasan Pengiriman</h2>
          <p className="text-sm text-gray-400 mb-6">Perbandingan dengan periode sebelumnya (30 hari terakhir).</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {kpi.map((item) => {
              const { icon: Icon, accent } = kpiMeta[item.id];
              const up = item.delta >= 0;
              const good = up === item.positiveIsGood;
              const Trend = up ? TrendingUp : TrendingDown;
              return (
                <Card key={item.id} className={cardClass}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <span className={`inline-flex size-11 items-center justify-center rounded-lg ring-1 ${accent}`}>
                        <Icon size={22} aria-hidden="true" />
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 text-xs font-medium ${
                          good ? "text-emerald-400" : "text-red-400"
                        }`}
                      >
                        <Trend size={14} aria-hidden="true" />
                        {up ? "+" : ""}
                        {item.delta.toLocaleString("id-ID")}%
                      </span>
                    </div>
                    <p className="mt-5 text-4xl font-semibold tracking-tight">{nf.format(item.value)}</p>
                    <p className="mt-1 text-sm text-gray-400">{item.label}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Grafik */}
        <section id="grafik" className="scroll-mt-24">
          <h2 className="text-2xl md:text-3xl font-medium mb-6">Grafik Pengiriman</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card className={cardClass}>
              <CardHeader>
                <CardTitle className="text-base font-medium">Volume per Kota Tujuan</CardTitle>
                <CardDescription className="text-gray-400">Jumlah paket bulan ini</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer config={volumeConfig} className="h-[340px] w-full">
                  <BarChart data={cityData} layout="vertical" margin={{ left: 0, right: 16 }}>
                    <CartesianGrid horizontal={false} stroke={gridStroke} />
                    <XAxis type="number" tick={tickStyle} tickLine={false} axisLine={false} />
                    <YAxis
                      type="category"
                      dataKey="kota"
                      width={84}
                      tick={tickStyle}
                      tickLine={false}
                      axisLine={false}
                    />
                    <ChartTooltip
                      cursor={{ fill: "rgba(255,255,255,0.05)" }}
                      content={<ChartTooltipContent className={tooltipClass} />}
                    />
                    <Bar dataKey="volume" fill="var(--color-volume)" radius={4} />
                  </BarChart>
                </ChartContainer>
              </CardContent>
            </Card>

            <Card className={cardClass}>
              <CardHeader>
                <CardTitle className="text-base font-medium">Ketepatan Waktu Harian</CardTitle>
                <CardDescription className="text-gray-400">Persentase tepat waktu, 14 hari terakhir</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer config={onTimeConfig} className="h-[340px] w-full">
                  <LineChart data={onTimeData} margin={{ left: 0, right: 16, top: 8 }}>
                    <CartesianGrid vertical={false} stroke={gridStroke} />
                    <XAxis
                      dataKey="tanggal"
                      tick={tickStyle}
                      tickLine={false}
                      axisLine={false}
                      interval="preserveStartEnd"
                      minTickGap={16}
                    />
                    <YAxis
                      domain={[70, 100]}
                      ticks={[70, 80, 90, 100]}
                      tickFormatter={(v: number) => `${v}%`}
                      width={44}
                      tick={tickStyle}
                      tickLine={false}
                      axisLine={false}
                    />
                    <ChartTooltip content={<ChartTooltipContent className={tooltipClass} />} />
                    <Line
                      dataKey="ontime"
                      type="monotone"
                      stroke="var(--color-ontime)"
                      strokeWidth={2.5}
                      dot={{ r: 3, fill: "var(--color-ontime)", strokeWidth: 0 }}
                      activeDot={{ r: 5 }}
                    />
                  </LineChart>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Cek Resi */}
        <section id="cek-resi" className="scroll-mt-24">
          <h2 className="text-2xl md:text-3xl font-medium mb-2">Cek Resi</h2>
          <p className="text-sm text-gray-400 mb-6">
            Masukkan nomor resi, misalnya <code className="text-gray-300">JNE001234567</code>.
          </p>

          <Card className={cardClass}>
            <CardContent className="p-6">
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3" noValidate>
                <label htmlFor="nomor-resi" className="sr-only">Nomor resi</label>
                <Input
                  id="nomor-resi"
                  value={resiInput}
                  onChange={(e) => setResiInput(e.target.value)}
                  placeholder="Nomor resi"
                  autoComplete="off"
                  aria-invalid={lookup.kind === "empty"}
                  aria-describedby="resi-feedback"
                  className="h-11 bg-black/40 border-gray-700 text-white placeholder:text-gray-500"
                />
                <button
                  type="submit"
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-white px-6 text-sm font-medium text-black transition hover:bg-gray-100 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60"
                >
                  <Search size={16} aria-hidden="true" />
                  Lacak
                </button>
              </form>

              <div id="resi-feedback" aria-live="polite" className="mt-6">
                {lookup.kind === "empty" && (
                  <p className="text-sm text-amber-300">Nomor resi wajib diisi. Ketik nomor resi lalu tekan Lacak.</p>
                )}

                {lookup.kind === "notfound" && (
                  <div className="flex items-start gap-3 rounded-lg border border-red-500/30 bg-red-500/10 p-4">
                    <PackageX className="mt-0.5 text-red-300" size={20} aria-hidden="true" />
                    <div>
                      <p className="text-sm font-medium text-red-200">Nomor resi tidak ditemukan</p>
                      <p className="text-sm text-gray-400">
                        Periksa kembali nomor <span className="text-gray-200">{lookup.query}</span> dan coba lagi.
                      </p>
                    </div>
                  </div>
                )}

                {lookup.kind === "found" && <ResiResult data={lookup.data} />}
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}

function ResiResult({ data }: { data: ResiData }) {
  const StatusIcon = statusIcon[data.status];
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-lg font-semibold">{data.nomor}</p>
          <p className="text-sm text-gray-400">
            {data.asal} → {data.tujuan}
          </p>
        </div>
        <Badge variant="outline" className={`w-fit gap-1.5 px-3 py-1 text-sm ${statusStyle[data.status]}`}>
          <StatusIcon size={14} aria-hidden="true" />
          {data.status}
        </Badge>
      </div>

      <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
        <div>
          <dt className="text-gray-500">Kurir</dt>
          <dd className="text-gray-200">{data.kurir}</dd>
        </div>
        <div>
          <dt className="text-gray-500">Update terakhir</dt>
          <dd className="text-gray-200">{data.updateTerakhir}</dd>
        </div>
      </dl>

      <ol className="relative ml-3 border-l border-gray-800">
        {data.riwayat.map((ev, i) => {
          const Icon = i === 0 ? statusIcon[data.status] : i === data.riwayat.length - 1 ? Package : MapPin;
          return (
            <li key={`${ev.waktu}-${i}`} className="mb-6 ml-6 last:mb-0">
              <span
                className={`absolute -left-3.5 flex size-7 items-center justify-center rounded-full ring-4 ring-gray-900 ${
                  i === 0 ? "bg-white text-black" : "bg-gray-800 text-gray-300"
                }`}
              >
                <Icon size={14} aria-hidden="true" />
              </span>
              <p className="text-sm font-medium text-gray-100">{ev.keterangan}</p>
              <p className="text-xs text-gray-400">
                {ev.lokasi} · {ev.waktu} WIB
              </p>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
